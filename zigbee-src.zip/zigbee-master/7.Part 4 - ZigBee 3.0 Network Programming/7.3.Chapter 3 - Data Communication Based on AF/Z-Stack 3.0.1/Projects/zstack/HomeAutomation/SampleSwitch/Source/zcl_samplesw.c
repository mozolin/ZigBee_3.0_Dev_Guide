/**************************************************************************************************
  Filename:       zcl_samplesw.c
  Revised:        $Date: 2015-08-19 17:11:00 -0700 (Wed, 19 Aug 2015) $
  Revision:       $Revision: 44460 $

  Description:    Zigbee Cluster Library - sample switch application.


  Copyright 2006-2013 Texas Instruments Incorporated. All rights reserved.

  IMPORTANT: Your use of this Software is limited to those specific rights
  granted under the terms of a software license agreement between the user
  who downloaded the software, his/her employer (which must be your employer)
  and Texas Instruments Incorporated (the "License").  You may not use this
  Software unless you agree to abide by the terms of the License. The License
  limits your use, and you acknowledge, that the Software may not be modified,
  copied or distributed unless embedded on a Texas Instruments microcontroller
  or used solely and exclusively in conjunction with a Texas Instruments radio
  frequency transceiver, which is integrated into your product.  Other than for
  the foregoing purpose, you may not use, reproduce, copy, prepare derivative
  works of, modify, distribute, perform, display or sell this Software and/or
  its documentation for any purpose.

  YOU FURTHER ACKNOWLEDGE AND AGREE THAT THE SOFTWARE AND DOCUMENTATION ARE
  PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
  INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, TITLE,
  NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL
  TEXAS INSTRUMENTS OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER CONTRACT,
  NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER
  LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
  INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE
  OR CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT
  OF SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
  (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.

  Should you have any questions regarding your right to use this Software,
  contact Texas Instruments Incorporated at www.TI.com.
**************************************************************************************************/

/*********************************************************************
  This application implements a ZigBee On/Off Switch, based on Z-Stack 3.0.

  This application is based on the common sample-application user interface. Please see the main
  comment in zcl_sampleapp_ui.c. The rest of this comment describes only the content specific for
  this sample applicetion.
  
  Application-specific UI peripherals being used:

  - none (LED1 is currently unused by this application).

  Application-specific menu system:

    <TOGGLE LIGHT> Send an On, Off or Toggle command targeting appropriate devices from the binding table.
      Pressing / releasing [OK] will have the following functionality, depending on the value of the 
      zclSampleSw_OnOffSwitchActions attribute:
      - OnOffSwitchActions == 0: pressing [OK] will send ON command, releasing it will send OFF command;
      - OnOffSwitchActions == 1: pressing [OK] will send OFF command, releasing it will send ON command;
      - OnOffSwitchActions == 2: pressing [OK] will send TOGGLE command, releasing it will not send any command.

*********************************************************************/

/*********************************************************************
 * INCLUDES
 */
#include "ZComDef.h"
#include "OSAL.h"
#include "AF.h"
#include "ZDApp.h"
#include "ZDObject.h"
#include "ZDProfile.h"
#include "MT_SYS.h"

#include "zcl.h"
#include "zcl_general.h"
#include "zcl_ha.h"
#include "zcl_samplesw.h"
#include "zcl_diagnostic.h"

#include "onboard.h"

/* HAL */
#include "hal_lcd.h"
#include "hal_led.h"
#include "hal_key.h"
#include "hal_adc.h"

#if defined (OTA_CLIENT) && (OTA_CLIENT == TRUE)
#include "zcl_ota.h"
#include "hal_ota.h"
#endif

#include "bdb.h"
#include "bdb_interface.h"

#include <stdio.h>

/*********************************************************************
 * MACROS
 */

/*********************************************************************
 * TYPEDEFS
 */

/*********************************************************************
 * GLOBAL VARIABLES
 */
byte zclSampleSw_TaskID;


/*********************************************************************
 * GLOBAL FUNCTIONS
 */

/*********************************************************************
 * LOCAL VARIABLES
 */

// Endpoint to allow SYS_APP_MSGs
static endPointDesc_t sampleSw_TestEp =
{
  SAMPLESW_ENDPOINT,                  // endpoint
  0,
  &zclSampleSw_TaskID,
  (SimpleDescriptionFormat_t *)&zclSampleSw_SimpleDesc,  // No Simple description for this test endpoint
  (afNetworkLatencyReq_t)0            // No Network Latency req
};


/*********************************************************************
 * LOCAL FUNCTIONS
 */
static void zclSampleSw_ProcessCommissioningStatus(bdbCommissioningModeMsg_t *bdbCommissioningModeMsg);


// Cluster
#define CLUSTER_P2P             0
#define CLUSTER_BROADCAST       1
#define CLUSTER_GROUPCAST       2

// GroupId
#define GROUP_ID                21

// P2P
static void zclSampleSw_AF_P2P(uint16 destNwkAddr,
                               uint16 cid,
                               uint8 len, uint8 *data);
// Broadcase
static void zclSampleSw_AF_Broadcast(uint16 cid,
                                     uint8 len, uint8 *data);
// Groupcast
static void zclSampleSw_AF_Groupcast(uint16 groupId,
                                     uint16 cid,
                                     uint8 len, uint8 *data);

// Process incoming message
static void zclSampleSw_AF_RxProc(afIncomingMSGPacket_t *MSGpkt);


/*********************************************************************
 * CONSTANTS
 */

/*********************************************************************
 * REFERENCED EXTERNALS
 */

/*********************************************************************
 * ZCL General Profile Callback table
 */

/*********************************************************************
 * @fn          zclSampleSw_Init
 *
 * @brief       Initialization function for the zclGeneral layer.
 *
 * @param       none
 *
 * @return      none
 */
void zclSampleSw_Init( byte task_id )
{
  zclSampleSw_TaskID = task_id;

  // Register for all key events - This app will handle all key events
  RegisterForKeys( zclSampleSw_TaskID );

  bdb_RegisterCommissioningStatusCB( zclSampleSw_ProcessCommissioningStatus );
  
  // Register for a test endpoint
  afRegister( &sampleSw_TestEp );
  
#ifdef ZDO_COORDINATOR
  bdb_StartCommissioning( BDB_COMMISSIONING_MODE_NWK_FORMATION |
                          BDB_COMMISSIONING_MODE_FINDING_BINDING );
  
  NLME_PermitJoiningRequest(255);
  
  // Broadcast
  osal_start_timerEx(zclSampleSw_TaskID, 
                     SAMPLEAPP_BROADCAST_EVT, 
                     SAMPLEAPP_BROADCAST_PERIOD);
  // groupcast
  osal_start_timerEx(zclSampleSw_TaskID, 
                     SAMPLEAPP_GROUPCAST_EVT, 
                     SAMPLEAPP_GROUPCAST_PERIOD);
#else
  bdb_StartCommissioning( BDB_COMMISSIONING_MODE_NWK_STEERING |
                          BDB_COMMISSIONING_MODE_FINDING_BINDING );
  // Add group
  aps_Group_t group = {
    .ID = GROUP_ID,
    .name = "",
  };
  aps_AddGroup(SAMPLESW_ENDPOINT, &group);
  
  // P2P
  osal_start_timerEx(zclSampleSw_TaskID, 
                     SAMPLEAPP_P2P_EVT, 
                     SAMPLEAPP_P2P_PERIOD);
#endif
}

/*********************************************************************
 * @fn          zclSample_event_loop
 *
 * @brief       Event Loop Processor for zclGeneral.
 *
 * @param       none
 *
 * @return      none
 */
uint16 zclSampleSw_event_loop( uint8 task_id, uint16 events )
{
  afIncomingMSGPacket_t *MSGpkt;
  (void)task_id;  // Intentionally unreferenced parameter


  if ( events & SYS_EVENT_MSG )
  {
    while ( (MSGpkt = (afIncomingMSGPacket_t *)osal_msg_receive( zclSampleSw_TaskID )) )
    {
      switch ( MSGpkt->hdr.event )
      {
        case AF_INCOMING_MSG_CMD:
          zclSampleSw_AF_RxProc( MSGpkt );
          break;

        default:
          break;
      }

      // Release the memory
      osal_msg_deallocate( (uint8 *)MSGpkt );
    }

    // return unprocessed events
    return (events ^ SYS_EVENT_MSG);
  }
 
  
#ifdef ZDO_COORDINATOR /* Coordinator */
  // Broadcast event
  if ( events & SAMPLEAPP_BROADCAST_EVT )
  {
    zclSampleSw_AF_Broadcast(CLUSTER_BROADCAST,
                             10, "Broadcast");
    
    osal_start_timerEx(zclSampleSw_TaskID, 
                     SAMPLEAPP_BROADCAST_EVT, 
                     SAMPLEAPP_BROADCAST_PERIOD);
    
    return ( events ^ SAMPLEAPP_BROADCAST_EVT );
  }
  
  // Groupcast event
  if ( events & SAMPLEAPP_GROUPCAST_EVT )
  {
    zclSampleSw_AF_Groupcast(GROUP_ID,
                             CLUSTER_GROUPCAST,
                             10, "Groupcast");
    
    osal_start_timerEx(zclSampleSw_TaskID, 
                     SAMPLEAPP_GROUPCAST_EVT, 
                     SAMPLEAPP_GROUPCAST_PERIOD);
    
    return ( events ^ SAMPLEAPP_GROUPCAST_EVT );
  }
#else
  // Rejoin Event
  if ( events & SAMPLEAPP_REJOIN_EVT )
  {
   bdb_StartCommissioning(BDB_COMMISSIONING_MODE_NWK_STEERING |
                      BDB_COMMISSIONING_MODE_FINDING_BINDING );
    
    return ( events ^ SAMPLEAPP_REJOIN_EVT );
  }
  
  // P2P Event
  if ( events & SAMPLEAPP_P2P_EVT )
  {
    zclSampleSw_AF_P2P(0x0000,
                       CLUSTER_P2P,
                       4, "P2P");
    
    osal_start_timerEx(zclSampleSw_TaskID, 
                     SAMPLEAPP_P2P_EVT, 
                     SAMPLEAPP_P2P_PERIOD);
    
    return ( events ^ SAMPLEAPP_P2P_EVT );
  }
#endif
  
  // Discard unknown events
  return 0;
}

  
/*********************************************************************
 * @fn      zclSampleSw_ProcessCommissioningStatus
 *
 * @brief   Callback in which the status of the commissioning process are reported
 *
 * @param   bdbCommissioningModeMsg - Context message of the status of a commissioning process
 *
 * @return  none
 */
static void zclSampleSw_ProcessCommissioningStatus(bdbCommissioningModeMsg_t *bdbCommissioningModeMsg)
{
  switch(bdbCommissioningModeMsg->bdbCommissioningMode)
  {
    case BDB_COMMISSIONING_FORMATION:
      if(bdbCommissioningModeMsg->bdbCommissioningStatus == BDB_COMMISSIONING_SUCCESS)
      {
        //After formation, perform nwk steering again plus the remaining commissioning modes that has not been processed yet
        bdb_StartCommissioning(BDB_COMMISSIONING_MODE_NWK_STEERING | bdbCommissioningModeMsg->bdbRemainingCommissioningModes);
      }
    break;
    case BDB_COMMISSIONING_NWK_STEERING:
      if(bdbCommissioningModeMsg->bdbCommissioningStatus == BDB_COMMISSIONING_SUCCESS)
      {
      }
      else
      {
        #ifdef ZDO_COORDINATOR
        #else
        osal_start_timerEx(zclSampleSw_TaskID, 
                           SAMPLEAPP_REJOIN_EVT, 
                           SAMPLEAPP_REJOIN_PERIOD);
        #endif
      }
    break;
  }
}

/**
 * @fn      zclSampleSw_AF_P2P
 *
 * @brief   P2P
 *
 * @param   destNwkAddr - destination address
 *          cid - cluster id
 *          len - data length
 *          data - data
 *
 * @return  none
 */
static void zclSampleSw_AF_P2P(uint16 destNwkAddr,
                               uint16 cid,
                               uint8 len, uint8 *data)
{
  afAddrType_t dstAddr;
  static uint8 transferId = 0;
 
  /* Destination */
  dstAddr.addrMode = afAddr16Bit;
  dstAddr.addr.shortAddr = destNwkAddr;
  dstAddr.endPoint = SAMPLESW_ENDPOINT;
  
  /* Transfer id */
  transferId++;
  
  /* Send */
  AF_DataRequest( &dstAddr, &sampleSw_TestEp,
                  cid,
                  len, data,
                  &transferId,
                  AF_DISCV_ROUTE, AF_DEFAULT_RADIUS );
}

/**
 * @fn      zclSampleSw_AF_Broadcast
 *
 * @brief   Broadcase
 *
 * @param   cid - cluster id
 *          len - data length
 *          data - data
 *
 * @return  none
 */
static void zclSampleSw_AF_Broadcast(uint16 cid,
                                     uint8 len, uint8 *data)
{
  afAddrType_t dstAddr;
  static uint8 transferId = 0;
 
  /* Destination */
  dstAddr.addrMode = afAddrBroadcast;
  dstAddr.addr.shortAddr = 0xFFFF;
  dstAddr.endPoint = SAMPLESW_ENDPOINT;
  
  /* Transfer id */
  transferId++;
  
  /* Send */
  AF_DataRequest( &dstAddr, &sampleSw_TestEp,
                  cid,
                  len, data,
                  &transferId,
                  AF_TX_OPTIONS_NONE, AF_DEFAULT_RADIUS );
}

/**
 * @fn      zclSampleSw_AF_Groupcast
 *
 * @brief   Groupcast
 *
 * @param   groupId - group id
 *          cid - cluster id
 *          len - data length
 *          data - data
 *
 * @return  none
 */
static void zclSampleSw_AF_Groupcast(uint16 groupId,
                                     uint16 cid,
                                     uint8 len, uint8 *data)
{
  afAddrType_t dstAddr;
  static uint8 transferId = 0;
 
  /* Destination */
  dstAddr.addrMode = afAddrGroup;
  dstAddr.addr.shortAddr = groupId;
  dstAddr.endPoint = SAMPLESW_ENDPOINT;
  
  /* Transfer id */
  transferId++;
  
  /* Send */
  AF_DataRequest( &dstAddr, &sampleSw_TestEp,
                  cid,
                  len, data,
                  &transferId,
                  AF_TX_OPTIONS_NONE, AF_DEFAULT_RADIUS );
}

/**
 * @fn      zclSampleSw_AF_RxProc
 *
 * @brief   Process incoming message
 *
 * @param   MSGpkt - incoming message
 *
 * @return  none
 */
static void zclSampleSw_AF_RxProc(afIncomingMSGPacket_t *MSGpkt)
{
  static uint8 p2pCnt = 0;
  static uint8 bcCnt = 0;
  static uint8 gcCnt = 0;
  
  switch( MSGpkt->clusterId )
  {
  case CLUSTER_P2P:
    p2pCnt++;
    
    HalLcdWriteStringValue( (char *)MSGpkt->cmd.Data, p2pCnt, 10, 3);
    HalLedSet(HAL_LED_1, HAL_LED_MODE_TOGGLE);
  break;
    
  case CLUSTER_BROADCAST:
    bcCnt++;
    
    HalLcdWriteStringValue( (char *)MSGpkt->cmd.Data, bcCnt, 10, 3);
  break;
  
  case CLUSTER_GROUPCAST:
    gcCnt++;
    
    HalLcdWriteStringValue( (char *)MSGpkt->cmd.Data, gcCnt, 10, 4);
  break;
  
  default:
  break;
  }
}
