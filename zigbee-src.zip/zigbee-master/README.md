* Study guide for this warehouse: [Click to read](http://www.sxf-iot.com)
* Content screenshot:  
<img src="https://images.gitee.com/uploads/images/2021/1102/182833_755e4da4_9594573.jpeg" width="350px;"/>
 
————————
  
**Shanxuefang** The only official website: [http://www.sxf-iot.com](http://www.sxf-iot.com)
  
**Shan Xuefang** The only WeChat public account: shanxuefang-iot
  
<img src="https://images.gitee.com/uploads/images/2021/0816/195523_fa9eb2dc_9594573.jpeg" width="200px;"/>

**Initiative**
  
At present, multi-origin code plagiarism, reselling and other behaviors have been discovered. We hereby propose: We hope that the majority of IoT enthusiasts will support originality. Your support is the driving force for our continuous updates! If you find other information that is similar to the information on this platform, it can be concluded that it is pirated, please refuse to use it!