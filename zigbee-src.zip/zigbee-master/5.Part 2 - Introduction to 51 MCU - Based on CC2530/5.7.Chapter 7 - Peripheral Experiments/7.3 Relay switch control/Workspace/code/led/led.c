#include "ioCC2530.h"
#include <stdio.h>
#include <stdint.h>

/**
 *  @brief  Maps a GPIO to the led controler.
 */
#define LED             P0_4

/**
 *  @brief  The led controler state.
 */
#define LED_ON          1 //!< on.
#define LED_OFF         0 //!< off.

static void delayMs(uint16_t nMs);
static void initLed(void);

void main()
{
    initLed();
  
    while(1) {
        // set led on
        printf("Set led to on!\r\n");
        LED = LED_ON; delayMs(500);
    
        // set led off
        printf("Set led to off!\r\n");
        LED = LED_OFF; delayMs(500);
    } /* while */
}

/**
 * @fn          delayMs
 * 
 * @brief	Millisecond delay
 *
 * @param 	nMs - how many milliseconds are delayed
 *
 * @return 	none
 *
 * @warning	Range of nMs value: 1-65535
 */
static void delayMs(uint16_t nMs)
{
    uint16_t i,j;
  
    for (i = 0; i < nMs; i++)
        for (j = 0; j < 535; j++);
}

/**
 * @fn          initLed
 * 
 * @brief	init. led gpio
 */
static void initLed()
{
    P0SEL &= ~(1<<4);
    P0DIR |=  (1<<4);
}
