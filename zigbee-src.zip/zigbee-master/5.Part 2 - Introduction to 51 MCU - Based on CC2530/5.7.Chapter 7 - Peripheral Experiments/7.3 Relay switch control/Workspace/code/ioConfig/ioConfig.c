#include "cc2530_ioctl.h"
#include <stdio.h>

/** @brief  GPIO mapping, led and button. */
// Led
#define RELAY_PORT        0       //!< Relay port.
#define RELAY_PIN         5       //!< Relay pin.
#define RELAY             P0_5    //!< Relay GPIO.

/** @brief  Led state. */
#define RELAY_ON          1 //!< on.
#define RELAY_OFF         0 //!< off.

static void delayMs(uint16_t nMs);
static void initRelay(void);

void main()
{
    initRelay();

    while(1) {
        delayMs(1000);

        RELAY = (RELAY == RELAY_ON)? RELAY_OFF : RELAY_ON;
    } /* while */
}

static void delayMs(uint16_t nMs)
{
    uint16_t i,j;
 
    for (i = 0; i < nMs; i++) for (j = 0; j < 535; j++);
}

static void initRelay()
{
    CC2530_IOCTL(RELAY_PORT, RELAY_PIN, CC2530_OUTPUT);

    RELAY = RELAY_OFF;
}
