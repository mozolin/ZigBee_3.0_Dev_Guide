#include "cc2530_ioctl.h"
#include <stdio.h>

/** @brief Debug mode
 *      open debug mode by defining  "DEBUG",
 *      close debug mode by defining "xDEBUG"
 */
#define DEBUG
#ifdef  DEBUG
  #define DEBUG_LOG(...) printf(__VA_ARGS__)
#else
  #define DEBUG_LOG(...)
#endif

/** @brief  GPIO mapping, led and button. */
// Led
#define LED_PORT        0       //!< Led port.
#define LED_PIN         4       //!< Led pin.
#define LED             P0_4    //!< Led GPIO.
// Button
#define BUTTON          P0_1    //!< Button GPIO.

/** @brief  Led state. */
#define LED_ON          1 //!< on.
#define LED_OFF         0 //!< off.

/** @brief  Button state. */
#define BUTTON_NORMAL   0 //!< normal state.
#define BUTTON_DOWN     1 //!< press-down.

static void delayMs(uint16_t nMs);
static void initLed(void);
static void initButton(void);

/* counter */
static uint8_t counter_g = 0;

/**
 * @fn      keyISR
 * 
 * @brief	Interrupt from key was pressed
 */
#pragma vector = P0INT_VECTOR
__interrupt void buttonISR(void)
{ 
    delayMs(10);

    if (BUTTON == BUTTON_DOWN) {
        DEBUG_LOG("counter_g: %d\r\n", counter_g);
        LED = (LED == LED_ON)? LED_OFF : LED_ON;
    }
    
    P0IFG = 0;
    P0IF  = 0;
} 

void main()
{
    initLed();
    initButton();
    
    while(1) {
        counter_g++;
        delayMs(100);
    }
}

static void delayMs(uint16_t nMs)
{
    uint16_t i,j;
    for (i = 0; i < nMs; i++) for (j = 0; j < 535; j++);
}

static void initLed(void)
{
    CC2530_IOCTL(LED_PORT, LED_PIN, CC2530_OUTPUT);
    LED = LED_OFF;
}

static void initButton(void)
{
    PICTL |= 0x01;   // Falling edge on input gives interrupt.
    P0IFG = 0x00; 	 // Clear the pin interrupt flag
    P0IEN |= (1<<1); // Enable P0.1 interrupt
    P0IF = 0x00; 	 // Clear the port0 interrupt status flag
    IEN1 |= 0x20; 	 // Enable P0 interrupt
    EA = 1; 		 // enable interrupts
}

