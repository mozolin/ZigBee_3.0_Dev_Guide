#ifndef HAL_M25PExx_H
#define HAL_M25PExx_H

#include "hal_flash_spi.h"

#ifdef __cplusplus
extern "C" {
#endif

/*
 *  M25PExx Model Configuration: HAL_M25PE80, HAL_M25PE40, HAL_M25PE20.
 */     
#if !defined(HAL_M25PE80) && !defined(HAL_M25PE40) && !defined(HAL_M25PE20)
    #define HAL_M25PE80
#endif

/*
 *  M25PExx Page Size, Sectors, Subsectors and pages:
 *    1Sector = 16Subsectors,
 *    1Subsector = 16Pages,
 *    1Page = 256Byte.
 */
#if defined(HAL_M25PE80)
    #define HAL_M25PExx_PAGE_SIZE      256
    #define HAL_M25PExx_LAST_ADDR      0xFFFFF
    #define HAL_M25PExx_SECTORS        16
    #define HAL_M25PExx_SUBSECTORS     256
    #define HAL_M25PExx_PAGES          4096
#elif defined(HAL_M25PE40)
#elif defined(HAL_M25PE20)
#endif

/**
 * @fn      halM25PExxInit
 * 
 * @brief	Init. M25PExx
 *
 * @return 	none
 */
void halM25PExxInit(void);

/**
 * @fn      halM25PExxRead
 * 
 * @brief   Read String from M25PExx
 *
 * @param   addr - Flash Address.
 * @param   pBuf - Pointer to buffer to copy the
 *                 bytes that read from Flash.
 * @param   len - Number of bytes to read.
 *
 * @return  Success: 0
 */
int halM25PExxRead(uint32 addr, uint8 *pBuf, uint16 len);

/**
 * @fn      halM25PExxWrite
 * 
 * @brief   Write String into M25PExx
 *
 * @param   addr - Flash Address
 * @param   pBuf - String
 * @param   len - Number of bytes to write
 *
 * @return  Success: 0
 */
int halM25PExxWrite(uint32 addr, uint8 *pBuf, uint16 len);


#ifdef __cplusplus
}
#endif

#endif /* #ifndef HAL_M25PExx_H */
