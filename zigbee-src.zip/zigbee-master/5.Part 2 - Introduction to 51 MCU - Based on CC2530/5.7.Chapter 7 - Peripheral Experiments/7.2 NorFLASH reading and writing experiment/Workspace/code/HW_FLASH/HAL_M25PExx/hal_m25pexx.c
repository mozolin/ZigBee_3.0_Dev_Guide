#include "hal_m25pexx.h"

/* M25PExx Commands. */
#define M25PExx_CMD_READ_STU_REG    0x05  // read status register
#define M25PExx_CMD_FAST_READ       0x0B  // read data bytes at higher speed
#define M25PExx_CMD_WRT_EN          0x06  // write enable
#define M25PExx_CMD_PW              0x0A  // page write
#define M25PExx_CMD_PP              0x02  // page program
#define M25PExx_CMD_PAGE_ER         0xDB  // page erase
#define M25PExx_CMD_SUBSEC_ER       0x20  // subsector erase
#define M25PExx_CMD_SEC_ER          0xD8  // sector erase
#define M25PExx_CMD_BULK_ER         0xC7  // bulk erase

/*  M25PExx Flags. */
#define M25PExx_DUMMY               0x00 // dummy byte
#define M25PExx_STAT_WIP            0x01 // nor flash write stat in progress

static int halM25PExxBusyCheck(void);

void halM25PExxInit(void)
{
    halFlashSpiInit();
}

int halM25PExxRead(uint32 addr, uint8 *pBuf, uint16 len)
{
    uint8 *pData = pBuf;
    
    if (addr > HAL_M25PExx_LAST_ADDR || halM25PExxBusyCheck() != 0) return -1;
    
    HAL_FLASH_SELECT();
    
    halFlashSpiTxByte(M25PExx_CMD_FAST_READ);
    halFlashSpiTxByte((uint8)(addr >> 16));
    halFlashSpiTxByte((uint8)(addr >> 8));
    halFlashSpiTxByte((uint8)(addr));
    
    /*
     *  In fast read mode:
     *  This is accomplished by adding eight ��dummy�� clocks 
     *  after the 24-bit address.
     */
    halFlashSpiTxByte(0);
    
    while (len--) *pData++ = halFlashSpiRxByte();
    
    HAL_FLASH_RELEASE();
    
    return 0;
}

int halM25PExxWrite(uint32 addr, uint8 *pBuf, uint16 len)
{
    uint8 *pData = pBuf;
  
    if ((addr + len) > HAL_M25PExx_LAST_ADDR) return -1;
    
    while (len) {
        if(halM25PExxBusyCheck() != 0) return -1;
        
        /* Write enable */
        HAL_FLASH_SELECT();
        halFlashSpiTxByte(M25PExx_CMD_WRT_EN);
        HAL_FLASH_RELEASE();
        
        HAL_FLASH_SELECT();
      
        /* Flash address */
        halFlashSpiTxByte(M25PExx_CMD_PW); 
        halFlashSpiTxByte((uint8)(addr >> 16)); 
        halFlashSpiTxByte((uint8)(addr >> 8)); 
        halFlashSpiTxByte((uint8)(addr)); 
        
        /* Can only write within any one page boundary, so prepare for next page 
           write if bytes remain.*/
        uint8 cnt = 0 - (uint8)addr;
        if (cnt) addr += cnt;
        else addr += HAL_M25PExx_PAGE_SIZE;

        do
        {
            halFlashSpiTxByte(*pData);

            cnt--;
            len--;
            pData++;
        } while (len && cnt);
        
        HAL_FLASH_RELEASE();
    } /* while (len) */
    
    return 0;
}

static int halM25PExxBusyCheck()
{
    uint16 delay = 0;     
    uint8  retry = 20;
    
    HAL_FLASH_SELECT();
  
    do
    {
        while(delay--); // delay
        delay = 1070;   // 32MHZ: ~1ms
        
        halFlashSpiTxByte(M25PExx_CMD_READ_STU_REG); 
    }while((halFlashSpiRxByte() & M25PExx_STAT_WIP) && retry--);
        
    HAL_FLASH_RELEASE();
    
    return (retry == 0)? -1 : 0;
}
