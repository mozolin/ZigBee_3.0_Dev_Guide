#ifndef HAL_FLASH_SPI_H
#define HAL_FLASH_SPI_H

#include "sw_spi.h"
#include "hw_spi.h" 

#ifdef __cplusplus
extern "C" {
#endif

/* 
 *  Config SPI bus.
 *  HAL_FLASH_SPI_SW - software SPI.
 *  HAL_FLASH_SPI_HW - hardware SPI.
 */
#if !defined(HAL_FLASH_SPI_SW) && !defined(HAL_FLASH_SPI_HW)
  #define HAL_FLASH_SPI_HW
#endif
   
/*
 *  SPI GPIOs:
 *  SCK : P1_5, 
 *  MOSI: P1_6,
 *  MISO: P1_7,
 *  CS  : P1_2,
 *  DC  : P1_4,
 *  RST : Don't need.
 */   
#ifdef HAL_FLASH_SPI_SW
    /* SCK */
    #define HAL_FLASH_SPI_SCK_PORT  1
    #define HAL_FLASH_SPI_SCK_PIN   5
    /* MOSI */
    #define HAL_FLASH_SPI_MO_PORT  	1
    #define HAL_FLASH_SPI_MO_PIN   	6
    /* MISO */
    #define HAL_FLASH_SPI_MI_PORT  	1
    #define HAL_FLASH_SPI_MI_PIN   	7
#endif
/* CS */
#define HAL_FLASH_SPI_CS_PORT   	1
#define HAL_FLASH_SPI_CS_PIN    	1
/* RST */
#define HAL_FLASH_SPI_RST_PORT  	SPI_IGNORE_IO
#define HAL_FLASH_SPI_RST_PIN   	SPI_IGNORE_IO

/**
 * @fn      halFlashSpiInit
 * 
 * @brief	Init. SPI bus
 *
 * @return 	none
 */
void halFlashSpiInit(void);

/** @brief   Select chip.
 */
#define HAL_FLASH_SELECT()  do {                                             \
    SPI_CS_SELECT(HAL_FLASH_SPI_CS_PORT, HAL_FLASH_SPI_CS_PIN);              \
    for(uint8 _FLASH_CS_DELAY = 0; _FLASH_CS_DELAY < 10; _FLASH_CS_DELAY++); \
} while(0)

/** @brief   Release chip.
 */
#define HAL_FLASH_RELEASE() SPI_CS_RELEASE(HAL_FLASH_SPI_CS_PORT, HAL_FLASH_SPI_CS_PIN)

/**
 * @fn      halFlashSpiTxByte
 * 
 * @brief   Tx a byte by SPI bus
 *
 * @param   b - byte
 */
void halFlashSpiTxByte(uint8 b);

/**
 * @fn      halFlashSpiRxByte
 * 
 * @brief   Rx a byte by SPI bus
 *
 * @return  byte from SPI
 */
uint8 halFlashSpiRxByte(void);


#ifdef __cplusplus
}
#endif

#endif /* #ifndef HAL_FLASH_SPI_H */
