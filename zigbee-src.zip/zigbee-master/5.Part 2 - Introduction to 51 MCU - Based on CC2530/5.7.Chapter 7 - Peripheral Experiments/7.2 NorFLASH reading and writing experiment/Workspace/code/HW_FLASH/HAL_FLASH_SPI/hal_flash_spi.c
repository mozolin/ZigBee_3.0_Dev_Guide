#include "hal_flash_spi.h"
#include "hal_delay.h"   

void halFlashSpiInit(void)
{
#ifdef HAL_FLASH_SPI_SW
    SW_SPI_INIT(HAL_FLASH_SPI_SCK_PORT, HAL_FLASH_SPI_SCK_PIN,
                HAL_FLASH_SPI_MO_PORT, HAL_FLASH_SPI_MO_PIN,
                HAL_FLASH_SPI_MI_PORT, HAL_FLASH_SPI_MI_PIN,
                SPI_CPOL_HIGH);
#else
    HwSPICfg_t cfg = {
        .alternate = HW_SPI1_ALT2,
        .bitOrder  = HW_SPI_BITORDER_MSB,
        .CPOL      = HW_SPI_CPOL_HIGH,
        .CPHA      = HW_SPI_CPHA_SECOND,
    };
    
    HwSPIInit(&cfg);
#endif
    
    SPI_CS_INIT(HAL_FLASH_SPI_CS_PORT, HAL_FLASH_SPI_CS_PIN);  
    
    /* Reset Flash */
#if defined(HAL_FLASH_SPI_RST_PORT) && \
    HAL_FLASH_SPI_RST_PORT != SPI_IGNORE_IO && \
    HAL_FLASH_SPI_RST_PIN != SPI_IGNORE_IO

    SPI_GPIO_OUTPUT(HAL_FLASH_SPI_RST_PORT, HAL_FLASH_SPI_RST_PIN);
    SPI_GPIO_CLEAR(HAL_FLASH_SPI_RST_PORT, HAL_FLASH_SPI_RST_PIN);
    for(uint16 delay = 0; delay < 1070; delay++);
    SPI_GPIO_SET(HAL_FLASH_SPI_RST_PORT, HAL_FLASH_SPI_RST_PIN);
#endif
}

void halFlashSpiTxByte(uint8 b)
{
#ifdef HAL_FLASH_SPI_SW
    SwSPITxByte( HAL_FLASH_SPI_SCK_PORT, HAL_FLASH_SPI_SCK_PIN,
                 HAL_FLASH_SPI_MO_PORT, HAL_FLASH_SPI_MO_PIN,
                 SPI_BITORDER_MSB,
                 SPI_CPOL_HIGH, HW_SPI_CPHA_SECOND,
                 b );
#else
    HwSPITxByte(HW_SPI1_ALT2, b);
#endif 
}

uint8 halFlashSpiRxByte(void)
{
    uint8 b;
  
#ifdef HAL_FLASH_SPI_SW
    SwSPIRxByte( HAL_FLASH_SPI_SCK_PORT, HAL_FLASH_SPI_SCK_PIN,
                 HAL_FLASH_SPI_MI_PORT, HAL_FLASH_SPI_MI_PIN,
                 SPI_BITORDER_MSB,
                 SPI_CPOL_HIGH, HW_SPI_CPHA_SECOND,
                 b );
#else
    halFlashSpiTxByte(0); // dummy
    b = HwSPIRxByte(HW_SPI1_ALT2);
#endif
      
    return b;
}
