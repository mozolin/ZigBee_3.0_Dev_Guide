#include "hal_m25pexx.h"
#include "uart.h"
#include "hal_delay.h"
#include <stdio.h>
#include <string.h>

void main(void)
{
    uint8 writeVal = 0;
    uint8 readVal  = 0;
    char  str[50];

    setSystemClk32MHZ();

    initUart0(USART_BAUDRATE_115200);
    halM25PExxInit();

    while(1) {   
        /* Write */
        sprintf(str, "Write: %d\r\n", writeVal);
        uart0Send((unsigned char *)str, strlen(str));

        if (halM25PExxWrite(0x12345, &writeVal, 1) != 0) {
            uart0Send("Write Error\r\n", 13);
            continue;
        }

        writeVal++;
        delayMs(SYSCLK_32MHZ, 1000);

        /* Read */
        if (halM25PExxRead(0x12345, &readVal, 1) != 0) {
            uart0Send("Read Error\r\n", 12);
            continue;
        }

        sprintf(str, "Read: %d\r\n", readVal);
        uart0Send((uint8 *)str, strlen(str));

        delayMs(SYSCLK_32MHZ, 1000);
    }
}
