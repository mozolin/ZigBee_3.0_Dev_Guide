#include "ioCC2530.h"
#include <stdio.h>
#include <stdint.h>

/** 
 *  @brief Debug mode,
 *      open debug mode by defining  "DEBUG",
 *      close debug mode by defining "xDEBUG".
 */
#define DEBUG
#ifdef  DEBUG
  #define DEBUG_LOG(...) printf(__VA_ARGS__)
#else
  #define DEBUG_LOG(...)
#endif

/**
 *  @brief  GPIO mapping, led and button.
 */
#define LED     P0_4 //!< led.
#define BUTTON  P0_1 //!< button.

/**
 *  @brief  Led state.
 */
#define LED_ON      1 //!< on.
#define LED_OFF     0 //!< off.

/**
 *  @brief  Button state.
 */
#define BUTTON_NORMAL   1 //!< normal state.
#define BUTTON_DOWN     0 //!< press-down.

static void delayMs(uint16_t nMs);
static void initLed(void);
static void initButton(void);

void main()
{
    initLed();
    initButton();

    while(1) {
        if (BUTTON != BUTTON_DOWN) continue;
        else { delayMs(10); if (BUTTON != BUTTON_DOWN) continue; }
    
        while (BUTTON == BUTTON_DOWN);
      
        DEBUG_LOG("Key Pressed!\r\n");
        LED = (LED == LED_ON)? LED_OFF : LED_ON;
    } /* while */
}

static void delayMs(uint16_t nMs)
{
    uint16_t i,j;
 
    for (i = 0; i < nMs; i++) for (j = 0; j < 535; j++);
}

static void initLed()
{
    P0SEL &= ~(1<<4);
    P0DIR |=  (1<<4);
}

static void initButton()
{
    P0SEL &= ~(1<<1);  // P0_1: General-purpose I/O
    P0DIR &= ~(1<<1);  // P0_1: Input
    P0INP &= ~(1<<1);  // P0_1: Pullup or Pulldown mode
    P2INP &= ~(1<<5);  // Pullup
}
