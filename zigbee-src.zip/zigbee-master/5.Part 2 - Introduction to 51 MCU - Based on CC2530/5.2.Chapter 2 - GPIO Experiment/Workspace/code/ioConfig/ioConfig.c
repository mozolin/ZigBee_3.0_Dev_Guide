#include "cc2530_ioctl.h"
#include <stdio.h>

/** @brief Debug mode
 *      open debug mode by defining  "DEBUG",
 *      close debug mode by defining "xDEBUG"
 */
#define DEBUG
#ifdef  DEBUG
  #define DEBUG_LOG(...) printf(__VA_ARGS__)
#else
  #define DEBUG_LOG(...)
#endif

/** @brief  GPIO mapping, led and button. */
// Led
#define LED_PORT        0       //!< Led port.
#define LED_PIN         4       //!< Led pin.
#define LED             P0_4    //!< Led GPIO.
// Button
#define BUTTON_PORT     0       //!< Button port.
#define BUTTON_PIN      1       //!< Button pin.
#define BUTTON          P0_1    //!< Button GPIO.

/** @brief  Led state. */
#define LED_ON          1 //!< on.
#define LED_OFF         0 //!< off.

/** @brief  Button state. */
#define BUTTON_NORMAL   1 //!< normal state.
#define BUTTON_DOWN     0 //!< press-down.

static void delayMs(uint16_t nMs);
static void initLed(void);
static void initButton(void);

void main()
{
    initLed();
    initButton();

    while(1) {
        if (BUTTON != BUTTON_DOWN) continue;
        else { delayMs(10); if (BUTTON != BUTTON_DOWN) continue; }
    
        while (BUTTON == BUTTON_DOWN);
      
        DEBUG_LOG("Key Pressed!\r\n");
        LED = (LED == LED_ON)? LED_OFF : LED_ON;
    } /* while */
}

static void delayMs(uint16_t nMs)
{
    uint16_t i,j;
 
    for (i = 0; i < nMs; i++) for (j = 0; j < 535; j++);
}

static void initLed()
{
    CC2530_IOCTL(LED_PORT, LED_PIN, CC2530_OUTPUT);
   
    LED = LED_OFF;
}

static void initButton()
{
    CC2530_IOCTL(BUTTON_PORT, BUTTON_PIN, CC2530_INPUT_PULLUP);
}
