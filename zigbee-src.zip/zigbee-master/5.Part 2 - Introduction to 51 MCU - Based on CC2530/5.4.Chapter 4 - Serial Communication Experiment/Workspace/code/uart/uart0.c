#include "hal_delay.h"
#include "cc2530_ioctl.h"
#include <stdio.h>

static void initUart0(void);
static void uart0Send(uint8_t *pMsg, uint8_t msgLen);

#pragma vector = URX0_VECTOR
__interrupt void URX0_ISR(void)
{
    uint8_t rxChar;
    
    URX0IF = 0;
    rxChar = U0DBUF;
    
    uart0Send(&rxChar, 1);
}

void main()
{
    setSystemClk32MHZ();
    initUart0();
  
    while(1) { }
}

/**
 * @fn      initUart0
 * 
 * @brief	init. uart0
 *
 * @note    Commonly Used Baud-Rate Settings for 32 MHz 
 *          System Clock:
 *            |-----------------------------------------|
 *            | Baud-Rate    BAUD_E    BAUD_M    Error  |
 *            |  2400          6        59       0.14%  |
 *            |  4800          7        59       0.14%  |
 *            |  9600          8        59       0.14%  |
 *            |  14400         8        216      0.03%  |
 *            |  19200         9        59       0.14%  |
 *            |  28800         9        216      0.03%  |
 *            |  38400         10       59       0.14%  |
 *            |  57600         10       216      0.03%  |
 *            |  76800         11       59       0.14%  |
 *            |  115200        11       216      0.03%  |
 *            |  230400        12       216      0.03%  |
 *            |-----------------------------------------|
 */
static void initUart0(void)
{
    PERCFG = 0x00;  // USART 0 I/O location: alternative 1 location
    P0SEL  = 0x3c;  // P0_2, P0_3 as peripheral function
    P2DIR &= ~0xc0; // Port 0 periphera 1st priority: USART 0

    U0CSR |= 0x80;  // USART mode select: UART mode

    /* Baud: 115200 */
    U0GCR  |= 11;   // BAUD_E
    U0BAUD |= 216;  // BAUD_M

    UTX0IF = 0;     // Clear tx-interrupt flag
    URX0IF = 0;     // Clear rx-interrupt flag
    URX0IE = 1;     // Enable rx interrupt
    EA = 1;         // Enable interrupts

    U0CSR |= 0x40;  // Enable UART-Rx
}

static void uart0Send(uint8_t *pMsg, uint8_t msgLen)
{
    uint8_t i;
    for (i = 0; i < msgLen; i++) {
        U0DBUF = pMsg[i];
        while (UTX0IF == 0);
        UTX0IF = 0;
    }
}
