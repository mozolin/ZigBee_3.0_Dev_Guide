#include "hal_delay.h"
#include "cc2530_ioctl.h"
#include <stdio.h>

/** @brief Debug mode
 *      open debug mode by defining  "DEBUG",
 *      close debug mode by defining "xDEBUG"
 */
#define DEBUG
#ifdef  DEBUG
  #define DEBUG_LOG(...) printf(__VA_ARGS__)
#else
  #define DEBUG_LOG(...)
#endif

/** @brief  GPIO mapping, led */
#define LED_PORT        0       //!< Led port.
#define LED_PIN         4       //!< Led pin.
#define LED             P0_4    //!< Led GPIO.

/** @brief  Led state. */
#define LED_ON          1       //!< on.
#define LED_OFF         0       //!< off.

static void initLed(void);
static void initWatchDogTimer(void);
static void watchDogFeet(void);

void main()
{
    initLed();
    initWatchDogTimer();
  
    while(1) {
    #if 0 //0 or 1
      
       delayMs(SYSCLK_16MHZ, 1500);
       
    #else
       
       delayMs(SYSCLK_16MHZ, 500);
       watchDogFeet();
       
       delayMs(SYSCLK_16MHZ, 500);
       watchDogFeet();
       
       delayMs(SYSCLK_16MHZ, 500);
       watchDogFeet();
       
    #endif
       
       LED = (LED == LED_ON)?LED_OFF : LED_ON;
    }
}

static void initLed(void)
{
    CC2530_IOCTL(LED_PORT, LED_PIN, CC2530_OUTPUT);
    LED = LED_OFF;
}

static void initWatchDogTimer(void)
{
    WDCTL = 0x00;  // First stop the WDT,
    WDCTL = 0x08;  // then start the WDT in Watchdog mode
}

static void watchDogFeet(void)
{
    /* 
     *    In Watchdog mode, when 0xA followed by 0x5 is written to bit[7:4],
     *  the timer is cleared! 
     */
    WDCTL |= (0xA << 4);
    WDCTL |= (0x5 << 4);
}
