#include "hal_delay.h"
#include "cc2530_ioctl.h"
#include <stdio.h>

/** @brief Debug mode
 *      open debug mode by defining  "DEBUG",
 *      close debug mode by defining "xDEBUG"
 */
#define DEBUG
#ifdef  DEBUG
  #define DEBUG_LOG(...) printf(__VA_ARGS__)
#else
  #define DEBUG_LOG(...)
#endif

/** @brief  GPIO mapping, led */
#define LED_PORT        0       //!< Led port.
#define LED_PIN         4       //!< Led pin.
#define LED             P0_4    //!< Led GPIO.

/** @brief  Led state. */
#define LED_ON          1       //!< on.
#define LED_OFF         0       //!< off.

/** @brief  counter */
static uint16_t counter_g = 0;

static void initLed(void);
static void initTimer3(void);

/*
 *  Timer3 interrupt service function 
 */
#pragma vector = T3_VECTOR
__interrupt void Timer3_ISR(void)
{
    // ~5s
    if (++counter_g == 2441) {
        counter_g = 0;
        
        DEBUG_LOG("Timer3 timeout -> 5-seconds!\r\n");
        LED = (LED == LED_ON)?LED_OFF : LED_ON;
    }
}

void main()
{
    initLed();
    initTimer3();
  
    while(1) { }
}

static void initLed(void)
{
    CC2530_IOCTL(LED_PORT, LED_PIN, CC2530_OUTPUT);
    LED = LED_OFF;
}

static void initTimer3(void)
{
    T3CTL = 0xE8;  // Tick frequency/128
                   // Overflow interrupt is enabled
                   // Free running, repeatedly count from 0x00 to 0xFF
    
    T3IE = 1;	   // Enable timer3 interrupt
    EA = 1;	       // Enable Interrupts

    T3CTL |= 0x10; // Start timer
}
