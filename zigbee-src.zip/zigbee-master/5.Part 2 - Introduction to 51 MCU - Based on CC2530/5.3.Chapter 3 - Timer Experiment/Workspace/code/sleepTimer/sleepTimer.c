#include "hal_delay.h"
#include "cc2530_ioctl.h"
#include <stdio.h>

/** @brief Debug mode
 *      open debug mode by defining  "DEBUG",
 *      close debug mode by defining "xDEBUG"
 */
#define DEBUG
#ifdef  DEBUG
  #define DEBUG_LOG(...) printf(__VA_ARGS__)
#else
  #define DEBUG_LOG(...)
#endif

/** @brief  GPIO mapping, led */
#define LED_PORT        0       //!< Led port.
#define LED_PIN         4       //!< Led pin.
#define LED             P0_4    //!< Led GPIO.

/** @brief  Led state. */
#define LED_ON          1       //!< on.
#define LED_OFF         0       //!< off.

/*
 *  Power modes: Active mode, PM1, PM2, PM3
 */
typedef enum
{
    POWER_MODE_IDLE   = 0,
    POWER_MODE_PM1    = 1,
    POWER_MODE_PM2    = 2,
    POWER_MODE_PM3    = 3,
    POWER_MODE_ACTIVE = 4,
    
    _POWER_MODE_MAX = POWER_MODE_ACTIVE,
}PowerMode_t;

static void initLed(void);
static void initSleepTimer(void);
static void setSleepPeriod(uint8_t nS);
static void setPowerMode(PowerMode_t mode);

/*
 *  Sleep timer ISR
 */
#pragma vector = ST_VECTOR
__interrupt void SleepTimer_ISR(void)
{
    STIF = 0;                        // Clear interrupt flag
    setPowerMode(POWER_MODE_ACTIVE); // Entry active power mode

    DEBUG_LOG("Activing...\r\n");
}

void main()
{
    initLed();
    initSleepTimer();
  
    while(1)
    {
        uint8_t i;
        for (i = 0; i < 6; i++) {
            LED = (LED == LED_ON)?LED_OFF : LED_ON;
            delayMs(SYSCLK_32MHZ ,250);
        }
        
        DEBUG_LOG("Sleeping...\r\n");
        
        setSleepPeriod(5);
        setPowerMode(POWER_MODE_PM2);
    }
}

static void initLed(void)
{
    CC2530_IOCTL(LED_PORT, LED_PIN, CC2530_OUTPUT);
    LED = LED_OFF;
}

static void initSleepTimer(void)
{
    ST2  = 0;
    ST1  = 0;
    ST0  = 0;
    
    STIE = 1;
    STIF = 0;
    EA   = 1;
}

static void setSleepPeriod(uint8_t nS)
{
    uint32_t sleepTimer = 0;
    sleepTimer  = (uint32_t)ST0;
    sleepTimer |= (uint32_t)ST1 << 8;
    sleepTimer |= (uint32_t)ST2 << 16;
    
    sleepTimer += (uint32_t)nS * 32768;
    
    ST2 = (uint8_t)(sleepTimer >> 16);
    ST1 = (uint8_t)(sleepTimer >> 8);
    ST0 = (uint8_t)(sleepTimer);
}

static void setPowerMode(PowerMode_t mode)
{
    if (mode > _POWER_MODE_MAX) {
        DEBUG_LOG("Power mode not found: %d\r\n", (int)mode);
        return;
    }
    
    if (mode == POWER_MODE_ACTIVE) {
        PCON = 0x00;
        return;       // Don't sleep
    }
    
    SLEEPCMD |= mode; // Set power mode      
    PCON = 0x01;      // Entering sleep mode
}
