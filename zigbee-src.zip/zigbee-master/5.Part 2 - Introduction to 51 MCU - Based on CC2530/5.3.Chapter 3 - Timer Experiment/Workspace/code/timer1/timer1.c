#include "hal_delay.h"
#include "cc2530_ioctl.h"
#include <stdio.h>

/** @brief Debug mode
 *      open debug mode by defining  "DEBUG",
 *      close debug mode by defining "xDEBUG"
 */
#define DEBUG
#ifdef  DEBUG
  #define DEBUG_LOG(...) printf(__VA_ARGS__)
#else
  #define DEBUG_LOG(...)
#endif

/** @brief  GPIO mapping, led */
#define LED_PORT        0       //!< Led port.
#define LED_PIN         4       //!< Led pin.
#define LED             P0_4    //!< Led GPIO.

/** @brief  Led state. */
#define LED_ON          1       //!< on.
#define LED_OFF         0       //!< off.

static void initLed(void);
static void initTimer1(void);

void main()
{
    uint8_t Counter = 0;
  
    initLed();
    initTimer1();
  
    while(1) {
        if (!(IRCON & 0x02)) continue; // Timer1 interrupt not pending

        IRCON &= ~(0x02); // Clear timer1 interrupt flag

        if (++Counter < 9) continue;  // ~5 second
        else Counter = 0;
  
        DEBUG_LOG("~5 Second.\r\n");
        LED = (LED == LED_ON)?LED_OFF : LED_ON;
    } /* while */
}

static void initLed(void)
{
    CC2530_IOCTL(LED_PORT, LED_PIN, CC2530_OUTPUT);
    LED = LED_OFF;
}

static void initTimer1(void)
{
  T1CTL = 0x0D; // Tick frequency/128, 
                // Free-running, repeatedly count from 0x0000 to 0xFFFF

  T1STAT= 0x21; // T1 counter-overflow interrupt flag, writing a 1 has no effect.
                // T1 channel 0 interrupt flag, writing a 1 has no effect.
}
