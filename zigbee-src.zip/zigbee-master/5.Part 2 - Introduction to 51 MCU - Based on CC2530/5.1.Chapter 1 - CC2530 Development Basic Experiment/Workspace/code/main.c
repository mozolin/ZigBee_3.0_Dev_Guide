#include "ioCC2530.h"
#include <stdio.h>

void main()
{
  printf("Hello World!\r\n");
  
  while(1)
  {
  }
}


