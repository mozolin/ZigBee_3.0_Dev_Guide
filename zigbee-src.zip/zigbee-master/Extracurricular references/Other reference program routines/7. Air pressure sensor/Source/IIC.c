/***********************************************************
**  FileName:         IIC.c
**  Introductions:    Standard IIC BUS Functions
**  Last Modify time: 2013.01.28
**  Update:           ��ǿIIC�ļ���ͨ���ԺͿɿ���
**  Author:           GuoZhenjiang
***********************************************************/
#include "IIC.h"
#include "UART.h"

//��ֵ����IIC��ʱ���е���ʱ�������ԣ�CC2530 MCU CLK=32MHz ʱȡ1-80�����ԡ�
static uint8 IIC_T = 20;

// IICʱ������ʱֵ
void IIC_DELAY(uint16 t)
{
    uint16 i;
    for(i=0; i<t; i++)
        ;
    return;
}

void IIC_Port_Init(void)
{
    PORT_IIC_SEL &= ~(1 << SDA_BIT);
    PORT_IIC_SEL &= ~(1 << SCL_BIT);

    SDA_DIR_OUTPUT;
    SCL_DIR_OUTPUT;
    CLR_SCL;
}
void IIC_Start(void)
{
    SDA_DIR_OUTPUT;
//    SCL_DIR_OUTPUT;

    SET_SDA;
    SET_SCL;
    IIC_DELAY(IIC_T);
    CLR_SDA;
    IIC_DELAY(IIC_T);
    CLR_SCL;
}

void IIC_Stop(void)
{
    SDA_DIR_OUTPUT;
    SCL_DIR_OUTPUT;

    CLR_SDA;
    SET_SCL;
    IIC_DELAY(IIC_T);
    SET_SDA;
    IIC_DELAY(IIC_T);
//    CLR_SCL;
}

void IIC_SendAck(IIC_Ack Ack)
{
    SDA_DIR_OUTPUT;
    SCL_DIR_OUTPUT;

    SDA_OUTPUT(Ack);
    SET_SCL;
    IIC_DELAY(IIC_T);
    CLR_SCL;
    IIC_DELAY(IIC_T);
}

IIC_Ack IIC_RecvAck(void)
{
    IIC_Ack ack;
    SDA_DIR_INPUT;
//    SCL_DIR_OUTPUT;

    SET_SCL;
    IIC_DELAY(IIC_T);
    if(PORT_IIC & (1 << SDA_BIT))
        ack = NACK;
    else
        ack = ACK;
    CLR_SCL;
    IIC_DELAY(IIC_T);
    return ack;
}

IIC_Ack IIC_SendByte(uint8 dat)
{
    uint8 i;
    SDA_DIR_OUTPUT;
//    SCL_DIR_OUTPUT;

    for(i=0; i<8; i++)
    {
        SDA_OUTPUT(dat & (0X80 >> i));
        SET_SCL;
        IIC_DELAY(IIC_T);
        CLR_SCL;
        IIC_DELAY(IIC_T);
    }
    return (IIC_RecvAck());
}

uint8 IIC_RecvByte(IIC_Ack ack)
{
    uint8 i, ReadVal;

    SDA_DIR_OUTPUT;
    SET_SDA;
    SDA_DIR_INPUT;
    for(i=0; i<8; i++)
    {
        ReadVal <<= 1;
        SET_SCL;
        IIC_DELAY(IIC_T);
        if(PORT_IIC & (1 << SDA_BIT))
            ReadVal |= 1;
        CLR_SCL;
        IIC_DELAY(IIC_T);
    }
    IIC_SendAck(ack);
    return ReadVal;
}

IIC_Ack IIC_WriteDev(uint8 DevAddr)
{
    return IIC_SendByte(DevAddr & 0XFE);
}

IIC_Ack IIC_ReadDev(uint8 DevAddr)
{
    return IIC_SendByte(DevAddr | 0X01);
}

IIC_Ack IIC_W_Single(uint8 DevAddr, uint8 RegAddr, uint8 RegData)
{
    IIC_Ack Ack;
    IIC_Start();
    if(ACK == IIC_WriteDev(DevAddr))
    {
        if(ACK == IIC_SendByte(RegAddr))
        {
            Ack = IIC_SendByte(RegData);
        }
        else
            return NACK;
    }
    else
        return NACK;

    IIC_Stop();
    return Ack;
}

uint8 IIC_R_Single(uint8 DevAddr, uint8 RegAddr)
{
    uint8 ReadResult;
    IIC_Start();
    if(ACK == IIC_WriteDev(DevAddr))
    {
        if(ACK == IIC_SendByte(RegAddr))
        {
            IIC_Start();
            IIC_ReadDev(DevAddr);
            ReadResult = IIC_RecvByte(NACK);
            IIC_Stop();
        }
        else
            return NACK;
    }
    else
        return NACK;
    return ReadResult;
}

void IIC_AddrTest(void)
{
    uint16 AddrTemp;
    // ϵͳʱ�ӳ�ʼ��
    SYSTEM_CLK_SET_32M_OSC_NOSPD;

    // LED �ƣ�D8 D9���˿ڳ�ʼ��
    LED_D8_D9_PortInit();

    // UART0��ʼ��
    UART0_Init( BAUD_115200, Position_1 );

    // IIC�˿ڳ�ʼ��
    IIC_Port_Init();
    for(AddrTemp=0; AddrTemp<=255; AddrTemp++)
    {
        UART0_Send("\r\nTesting:\t", sizeof("\r\nTesting:\t")-1);
        UART0_Dis_uNum(AddrTemp);
        if(ACK == IIC_W_Single(AddrTemp, 0, 0))
        {
            UART0_Send("\tSuccess!\r\n", sizeof("\tSuccess!\r\n")-1);
        }
        else
        {
            UART0_Send("\r\n", sizeof("\r\n")-1);
        }
        LED_D8_ON;
        delay_10ms(1);
        LED_D8_OFF;
    }
}