
#include"BMP085.h"

short AC1, AC2, AC3, B1, B2, MB, MC, MD, oss;
unsigned short AC4, AC5, AC6;

union
{
    uint16 T_up[2];
    long P;
}Press;

union
{
    uint16 T_ut[2];
    long T;
}Temp;

long UT, UP, X1, X2, X3, B3, B5, B6;
unsigned long B4, B7;

void BMP085_Init(void)
{
    uint16 Msb, Lsb;
    Msb = IIC_R_Single(BMP085_IICDevAddr, BMP085_AC1);
    Lsb = IIC_R_Single(BMP085_IICDevAddr, BMP085_AC1 + 1);
    AC1 = (Msb << 8) | Lsb;

    Msb = IIC_R_Single(BMP085_IICDevAddr, BMP085_AC2);
    Lsb = IIC_R_Single(BMP085_IICDevAddr, BMP085_AC2 + 1);
    AC2 = (Msb << 8) | Lsb;

    Msb = IIC_R_Single(BMP085_IICDevAddr, BMP085_AC3);
    Lsb = IIC_R_Single(BMP085_IICDevAddr, BMP085_AC3 + 1);
    AC3 = (Msb << 8) | Lsb;

    Msb = IIC_R_Single(BMP085_IICDevAddr, BMP085_AC4);
    Lsb = IIC_R_Single(BMP085_IICDevAddr, BMP085_AC4 + 1);
    AC4 = (Msb << 8) | Lsb;

    Msb = IIC_R_Single(BMP085_IICDevAddr, BMP085_AC5);
    Lsb = IIC_R_Single(BMP085_IICDevAddr, BMP085_AC5 + 1);
    AC5 = (Msb << 8) | Lsb;

    Msb = IIC_R_Single(BMP085_IICDevAddr, BMP085_AC6);
    Lsb = IIC_R_Single(BMP085_IICDevAddr, BMP085_AC6 + 1);
    AC6 = (Msb << 8) | Lsb;

    Msb = IIC_R_Single(BMP085_IICDevAddr, BMP085_B1);
    Lsb = IIC_R_Single(BMP085_IICDevAddr, BMP085_B1 + 1);
    B1 = (Msb << 8) | Lsb;

    Msb = IIC_R_Single(BMP085_IICDevAddr, BMP085_B2);
    Lsb = IIC_R_Single(BMP085_IICDevAddr, BMP085_B2 + 1);
    B2 = (Msb << 8) | Lsb;

    Msb = IIC_R_Single(BMP085_IICDevAddr, BMP085_MB);
    Lsb = IIC_R_Single(BMP085_IICDevAddr, BMP085_MB + 1);
    MB = (Msb << 8) | Lsb;

    Msb = IIC_R_Single(BMP085_IICDevAddr, BMP085_MC);
    Lsb = IIC_R_Single(BMP085_IICDevAddr, BMP085_MC + 1);
    MC = (Msb << 8) | Lsb;

    Msb = IIC_R_Single(BMP085_IICDevAddr, BMP085_MD);
    Lsb = IIC_R_Single(BMP085_IICDevAddr, BMP085_MD + 1);
    MD = (Msb << 8) | Lsb;
}
IIC_Ack BMP085_Fun(BMP085FunSel_t FunSel)
{
    return IIC_W_Single(BMP085_IICDevAddr, BMP085_CtlRegAddr, FunSel);
}
int32 BMP085ReadValue(BMP085FunSel_t FunSel)
{
  int32 Result = 0, Val[3];
  IIC_Start();
  IIC_WriteDev(BMP085_IICDevAddr);
  IIC_SendByte(BMP085_TP_MSB);

  IIC_Start();
  IIC_ReadDev(BMP085_IICDevAddr);
  Val[0] = IIC_RecvByte(ACK);
  Val[1] = IIC_RecvByte(ACK);
  Val[2] = IIC_RecvByte(NACK);
  IIC_Stop();
  switch(FunSel)
  {
    case BMP085_TEMP_16BIT: oss = 0; break;
    case BMP085_PRES_16BIT: oss = 0; break;
    case BMP085_PRES_17BIT: oss = 1; break;
    case BMP085_PRES_18BIT: oss = 2; break;
    case BMP085_PRES_19BIT: oss = 3; break;
    default               : oss = 0; break;
  }
  //Temperature in 0.1��, Pressure in Pa.
  Result = ((Val[0] << 16) + (Val[1] << 8) + Val[2]) >> (8 - oss);

  return Result;
}

void BMP085Test(void)
{
    LED_D8_D9_PortInit();
    UART0_Init(BAUD_115200, Position_1);
    // bmp085_get_cal_param
    BMP085_Init();
    while(1)
    {
        // bmp085_get_ut
        //�����¶�ת������ȡ
        if(ACK != BMP085_Fun(BMP085_TEMP_16BIT))
        {
            LED_D9_ON;  // ��ȡ������LED_D9�����
        }
        else
            LED_D9_OFF;//LED_D9_ON; LED_D9_OFF;
        delay_10ms(5);
        UT = BMP085ReadValue(BMP085_TEMP_16BIT);
        BMP085_Fun(BMP085_TEMP_16BIT);
        delay_10ms(5);
        UT = BMP085ReadValue(BMP085_TEMP_16BIT);

        // bmp085_get_up
        //������ѹת������ȡ
        if(ACK != BMP085_Fun(BMP085_PRES_16BIT))
        {
            LED_D9_ON;  // ��ȡ������LED_D9�����
        }
        else
            LED_D9_OFF;//LED_D9_ON; LED_D9_OFF;
        delay_10ms(5);
        UP = BMP085ReadValue(BMP085_PRES_16BIT);
        BMP085_Fun(BMP085_PRES_16BIT);
        delay_10ms(5);
        UP = BMP085ReadValue(BMP085_PRES_16BIT);

        // bmp085_get_temperature
        // ����������ʽ��������,�õ��¶�0.1�棬��ѹPa��
        X1 = ((UT - AC6) * AC5) >> 15; // X1 = (UT - AC6) * AC5 / 2^15;
        X2 = (MC << 11) / (X1 +MD); // X2 = MC * 2^11 / (X1 +MD);
        B5 = X1 + X2;
        Temp.T = (B5 + 8) >> 4; // T = (B5 + 8) / 2^4;

        // bmp085_cal_pressure
        B6 = B5 - 4000;
        X1 = (B2 * ((B6 * B6) >> 12)) >> 11; // X1 = (B2 * (B6 * B6 / 2^12)) / 2^11;
        X2 = (AC2 * B6) >> 11; // X2 = AC2 * B6 / 2^11;
        X3 = X1 + X2;
        B3 = (((AC1 << 2) + X3) << oss + 2) >> 2; // B3 = ((AC1 * 4 + X3) << oss + 2) / 4;
        X1 = AC3 * B6 >> 13; // X1 = AC3 * B6 / 2^13;
        X2 = (B1 * ((B6 * B6) >> 12)) >> 16; // X2 = (B1 * (B6 * B6 / 2^12)) / 2^16;
        X3 = ((X1 + X2) + 2) >> 2; // X3 = ((X1 + X2) + 2) / 2^2;
        B4 = (AC4 * (unsigned long)(X3 + 32768)) >> 15; // B4 = AC4 * (unsigned long)(X3 + 32768) / 2^15;
        B7 = ((unsigned long)UP - B3) * (50000 >> oss);
        if(B7 < 0x80000000)
        {
            Press.P= (B7 << 1) / B4; // P= (B7 * 2) / B4;
        }
        else
        {
            Press.P = (B7 / B4) << 1; // P = (B7 / B4) * 2;
        }
        X1 = (Press.P >> 8) * (Press.P >> 8); // X1 = (P / 2^8) * (P / 2^8);
        X1 = (X1 * 3038) >> 16; // X1 = (X1 * 3038) / 2^16;
        X2 = (-7357 * Press.P) >> 16; // X2 = (-7357 * P) / 2^16;
        Press.P = Press.P + ((X1 + X2 + 3791) >> 4); // P = P + (X1 + X2 + 3791) / 2^4;



        UART0_Send("Temperature:", sizeof("Temperature:")-1);
        //UART0_Dis_uNum(Temp.T);
        UART0_Dis_uNum(Temp.T_ut[1]);
        UART0_Dis_uNum(Temp.T_ut[0]);
        UART0_Send("\t", sizeof("\t")-1);

        UART0_Send("Pressure:", sizeof("Pressure:")-1);
        //UART0_Dis_uNum( Press.P );
        UART0_Dis_uNum( Press.T_up[1] );
        UART0_Dis_uNum( Press.T_up[0] );
        UART0_Send("\r\n", sizeof("\r\n")-1);

        LED_D8_ON;
        delay_10ms(5);
        LED_D8_OFF;
        delay_10ms(50);
    }
}