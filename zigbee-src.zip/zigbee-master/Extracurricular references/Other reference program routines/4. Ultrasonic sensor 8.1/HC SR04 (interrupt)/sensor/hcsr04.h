#ifndef __HCSR04_H__
#define __HCSR04_H__


#define uchar unsigned char 
#define uint unsigned int 

//�������ӣ�
#define TRIG P1_3    //P1_2    
#define ECHO P0_7    //P0_1 
 
extern  uchar RG; 
extern  uchar H1; 
extern  uchar L1; 
extern  uchar H2; 
extern  uchar L2; 
extern  uchar H3; 
extern  uchar L3; 
extern  uint data; 
extern  float distance; 
extern  uchar LoadRegBuf[4]; 

//void Delay(uint n); 
void Delay_1us(uint microSecs); 
void Delay_10us(uint n); 
void Delay_1s(uint n); 
void SysClkSet32M(); 
void Init_UltrasoundRanging(); 
void UltrasoundRanging(uchar *ulLoadBufPtr); 
__interrupt void P0_ISR(void); 


#endif