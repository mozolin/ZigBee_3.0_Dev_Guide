[Development software installation package](https://pan.baidu.com/s/1t0psD10befhcMbqvl1rt5g?pwd=2333)  
Extraction code: 2333  
